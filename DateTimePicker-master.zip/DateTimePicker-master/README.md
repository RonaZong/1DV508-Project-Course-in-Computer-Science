DateTimePicker
==============

Basic date and time picker control for JavaFX

Since there isn't one native to JavaFX yet, I made this simple JavaFX control for picking date and time.  It uses javafx.scene.control.DatePicker to select date.  Time selection is done using buttons for hours and sliders for minutes and seconds.

Only been tested with Java 8 update 11 and in the United States Locale, so no guarantees if it works with other languages and/or locales.

Icons used are from the Dusseldorf icon pack found here: http://pc.de/icons/ and are licensed under CC 3.0
